<?php

abstract class Controller
{

    public function __construct()
    {

    }

    public function render($file, $data = [])
    {
        extract($data);
        ob_start();
        require_once PATH . "views/" . lcfirst(get_class($this)) . "/" . $file . ".php";
        $contenu = ob_get_clean();
        require_once "./views/layout/default.php";

    }


    public function isValid($data)
    {

        foreach ($data as $element) {

            if (empty($element)) {
                return false;
            }
        }
        return true;
    }


}