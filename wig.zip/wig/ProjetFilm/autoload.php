<?php
function autoload($classe){
$tab = [PATH."app/",PATH."controllers/",PATH."models/"];
foreach($tab as $chemin){
    if(file_exists($chemin.$classe.".php")){
require_once($chemin.$classe.".php");

    }


}

}

spl_autoload_register("autoload");