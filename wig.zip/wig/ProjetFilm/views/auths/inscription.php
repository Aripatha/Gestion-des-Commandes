
<form class="m-5" method="post">
 <div class="mb-3">
    <label for="nom" class="form-label">Nom</label>
    <input type="text" class="form-control" id="nom" name="nom" >
    
  </div>
  <div class="mb-3">
    <label for="prenom" class="form-label">Prenom</label>
    <input type="text" class="form-control" id="prenom" name="prenom" >
    
  </div>
  <div class="mb-3">
    <label for="date_naissance" class="form-label">Birth date</label>
    <input type="date" class="form-control" id="date_naissance" name="date_naissance" >
    
  </div>
  <div class="mb-3">
    <label for="telephone" class="form-label">telephone</label>
    <input type="text" class="form-control" id="telephone" name="telephone" >
    
  </div>
  <div class="mb-3">
    <label for="email" class="form-label">Email address</label>
    <input type="email" class="form-control" id="email"  name="email">   
  </div>
  
  <div class="mb-3">
    <label for="mot_de_passe" class="form-label">Password</label>
    <input type="password" class="form-control" id="mot_de_passe" name="mot_de_passe">
  </div>
  <div class="mb-3">
    <label for="confirm_mdp" class="form-label">Confirm Password</label>
    <input type="password" class="form-control" id="confirm_mdp" name="confirm_mdp">
  </div>
  <input class="btn btn-primary" type="submit" value="Sign In" name="sign_in">
</form>

