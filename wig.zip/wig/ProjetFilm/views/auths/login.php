
<form class="m-5" method="post">
 

  <div class="mb-3">
    <label for="email" class="form-label">Email address</label>
    <input type="email" class="form-control" id="email"  name="email">   
  </div>
  
  <div class="mb-3">
    <label for="mot_de_passe" class="form-label">Password</label>
    <input type="password" class="form-control" id="mot_de_passe" name="mot_de_passe">
  </div>

 <?php if(isset($erreur)){
    ?>
      <div class="alert alert-danger" role="alert">
            <?php echo $erreur;  ?>
        </div>
    <?php 
 }     ?>

  <input class="btn btn-primary" type="submit" value="Log In" name="log_in">
</form>

