<div class="container">
    <div class="row">
        <?php
        foreach ($films as $film) {

            ?>
            <div class="card col-3 m-3" style="width: 18rem;">
                <img src=<?=
                (isset($film->chemin_image)) ? URI . $film->chemin_image
                    : URI . 'assets/image.jpeg';

                ?> class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?= $film->nom; ?></h5>
                    <p class="card-text"><?= $film->courte_description; ?></p>
                    <a href=<?= URI . "paniers/ajouter/" . $film->id_film; ?> class="btn btn-primary">Ajouter Panier</a>
                </div>
            </div>
            <?php
        }
        ?>

    </div>


</div>