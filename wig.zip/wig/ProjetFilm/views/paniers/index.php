<table class="table container">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Image</th>
        <th scope="col">Nom</th>
        <th scope="col">Prix</th>
        <th scope="col">Quantite</th>
        <th scope="col">Courte description</th>
        <th scope="col">Actions</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $cmp = 1;
    foreach ($films as $film) {
        $quantite = $film[0];
        $film = $film[1];
        ?>
        <form method="post" action=<?= URI . "paniers/modifier/" . $film->id_film; ?>>
            <tr>
                <th scope="row"><?= $cmp++; ?></th>
                <td><img height="100px" width="100px" src=<?=
                    (isset($film->chemin_image)) ? URI . $film->chemin_image
                        : URI . 'assets/image.jpeg';

                    ?> alt=""></td>
                <td><?= $film->nom; ?></td>
                <td><?= $film->prix; ?></td>
                <td>

                    <input name="quantite" min="0" max=<?= $film->quantite; ?> type="number" value=<?= $quantite; ?>>

                </td>
                <td><?= $film->courte_description; ?></td>
                <td><?= $film->courte_description; ?></td>

                <td class="row">
                    <input type="submit" name="submit" class="btn btn-info col" value="Modifier">
                    <div class="col-1"></div>
                    <a href=<?= URI . "paniers/supprimer/" . $film->id_film; ?> class="btn btn-danger col"><i
                            class="bi bi-trash3-fill"></i></a>

                </td>
            </tr>
        </form>
    <?php } ?>
    </tbody>
</table>