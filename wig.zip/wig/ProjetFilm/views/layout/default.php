<header >
    <?php include_once(PATH."views/layout/header.php");?>
</header>
<main>
    <?php
    echo $contenu ; 
    ?>
</main>
<footer>
    <h3>Je suis le footer</h3>
</footer>