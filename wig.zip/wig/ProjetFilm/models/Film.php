<?php

class Film extends Model
{
    public function __construct()
    {
        parent::__construct();
        $this->table = "Film";
    }

    public function save($data)
    {
        $this->sql = "insert into " . $this->table . " (nom, prix, description, courte_description, quantite) 
                        VALUE (:nom, :prix, :description, :courte_description, :quantite)";
        return $this->getLines($data, null);
    }

    public function getAll()
    {
        $this->sql = "SELECT f.*, i.chemin_image FROM " . $this->table . " f left join Image i on f.id_film = i.id_film";
        return $this->getLines();
    }

    public function getOneById($data)
    {
        $this->sql = "SELECT f.*, i.chemin_image FROM " . $this->table . " f left join Image i on f.id_film = i.id_film  where f.id_film = :id_film";
        return $this->getLines($data, true);
    }

    public function supprimer($data)
    {
        $this->sql = "delete from " . $this->table . " where id_film=:id_film";
        return $this->getLines($data, null);
    }

}