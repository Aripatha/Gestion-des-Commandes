<?php 
Class Auth extends Model {
    public function __construct(){
        parent::__construct();
        $this->table ="Utilisateur";
    }
    
    public function inscription($data){
        $this->sql = " INSERT INTO $this->table (nom,prenom,email,telephone,date_naissance,mot_de_passe,id_role)
        VALUES (:nom,:prenom,:email,:telephone,:date_naissance,:mot_de_passe,:id_role)";
      return  $this->getLines($data,null);

    }
    public function findByEmail($data){
        $this->sql = " SELECT * from $this->table WHERE email = :email";
        return  $this->getLines($data,true);
        
    }
    public function deleteByEmail($data){
        $this->sql = " DELETE FROM $this->table WHERE email = :email";
        return  $this->getLines($data,null);
        
    }
    public function updateByEmail($data){
        $this->sql = "UPDATE $this->table SET  email = :email, nom = :nom, prenom = :prenom,date_naissance = :date_naissance,mot_de_passe = :mot_de_passe  WHERE id_utilisateur = :id_utilisateur";
        return  $this->getLines($data,null);
        
    }
    public function logIn($data){
        $this->findByEmail($data);
        
    }

}