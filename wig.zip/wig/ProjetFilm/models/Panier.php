<?php

class Panier
{
    public function __construct()
    {
        if (!isset($_SESSION['Panier'])) {
            $_SESSION['Panier'] = [];
        }
    }

    public function ajouter($id, $quantite)
    {
        $_SESSION['Panier'][$id] = $quantite;
    }

    public function supprimer($id)
    {
        unset($_SESSION['Panier'][$id]);
    }

    public function getAllPanier()
    {
        $films = [];
        foreach ($_SESSION['Panier'] as $id => $quantite) {

            $data = ["id_film" => $id];
            $film = new Film();
            //[0 ,[34,stdClass()] ]
            $films[] = [$quantite, $film->getOneById($data)];
        }
        return $films;
    }

}