<?php
session_start();
define("URI", "http://localhost:8080/H2024/CM2/443/ProjetFilm/");
define('PATH', str_replace('index.php', '', $_SERVER['SCRIPT_FILENAME']));

include_once "./autoload.php";
// var_dump($_GET);
$params = $_GET['p'];
$params = explode('/', $params);

$nomController = ucfirst($params[0]);

$controller = new $nomController();

$action = $params[1];

$controller->$action();









// print_r($params) ;