<?php

class Paniers extends Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $panier = new Panier();
        $films = $panier->getAllPanier();
        $this->render('index', compact('films'));

    }

    public function ajouter()
    {
        $this->addMod();
        header("Location: " . URI . "films/index");
    }

    private function addMod($quantiter = 1)
    {
        $params = explode('/', $_GET['p']);
        if (isset($params[2])) {
            if (is_numeric($params[2])) {
                $panier = new Panier();
                $panier->ajouter($params[2], $quantiter);
            }
        }
    }

    public function modifier()
    {
        $this->addMod($_POST['quantite']);
        $this->index();
    }

    public function supprimer()
    {
        $params = explode('/', $_GET['p']);
        if (isset($params[2])) {
            if (is_numeric($params[2])) {
                $panier = new Panier();
                $panier->supprimer($params[2]);
            }
        }

        $this->index();

    }

}