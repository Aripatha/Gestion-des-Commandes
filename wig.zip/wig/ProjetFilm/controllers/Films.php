<?php

class Films extends Controller
{
    public function __construct()
    {
        parent::__construct();

    }

    public function index()
    {
        $film = new Film();
        $films = $film->getAll();
        $films = ["films" => $films];
//        var_dump($_SESSION["Utilisateur"]);
        $this->render("index", $films);
    }

    public function ajout()
    {
        if (isset($_POST["save"])) {
            if ($this->isValid($_POST)) {
                $film = new Film();
                unset($_POST["save"]);
                $film->save($_POST);
                global $oPDO;
                $id_film = $oPDO->lastInsertId();
                $this->upload($id_film);
                header("Location: " . URI . "films/index");
            }

        }


        $this->render("ajout");
    }

    public function upload($id_film)
    {
        if (isset($_FILES["image"]) && $_FILES["image"]["error"] === UPLOAD_ERR_OK) {
            $image_name = $_FILES["image"]["name"];
            $image_tmp = $_FILES["image"]["tmp_name"];
            $image_destination = "assets/images/" . basename($image_name); // Chemin de destination du fichier sur le serveur

            // Vérifier que le fichier est une image (facultatif mais recommandé)
            // images/a-2-1634829071.JPG
            $image_type = strtolower(pathinfo($image_destination, PATHINFO_EXTENSION));
            // jpg
            if (!in_array($image_type, array("jpg", "jpeg", "png", "gif"))) {
                echo "Seules les images JPG, JPEG, PNG et GIF sont autorisées.";
                exit();
            }

            // Déplacer l'image téléchargée vers le dossier spécifié
            if (move_uploaded_file($image_tmp, PATH . $image_destination)) {
                $image = new Image();
                $data = ["id_film" => $id_film,
                    "chemin_image" => $image_destination];
                $image->upload($data);
            }
        }
    }

    public function admin()
    {
        $film = new Film();
        $films = $film->getAll();
        $this->render('admin', compact("films"));
    }

    public function supprimer()
    {
        $params = explode('/', $_GET['p']);
        if (isset($params[2])) {
            if (is_numeric($params[2])) {
                $film = new Film();
                $data = ["id_film" => $params[2]];
                if ($film->supprimer($data)) {
                    header("Location: " . URI . "films/admin");
                }
            }
        }

    }


}