<?php

class Auths extends Controller
{

    public function inscription()
    {
        if (isset($_POST["sign_in"])) {

            if ($this->isValid($_POST)) {
                if ($_POST["mot_de_passe"] === $_POST["confirm_mdp"]) {
                    // var_dump($_POST);
                    //unset() pour supprimer des elem du tab
                    unset($_POST["sign_in"], $_POST["confirm_mdp"]);
                    $_POST["mot_de_passe"] = password_hash($_POST["mot_de_passe"], PASSWORD_DEFAULT);
                    $_POST["id_role"] = 2;
                    $oAuth = new Auth();
                    $oAuth->inscription($_POST);
                }
            }


        }
        $this->render("inscription");
    }

    public function login()
    {
        //echo password_hash("toto",PASSWORD_DEFAULT);

        if (isset($_POST["log_in"])) {

            if ($this->isValid($_POST)) {
                if ($_POST["mot_de_passe"]) {
                    $mot_de_passe = $_POST["mot_de_passe"];
                    unset($_POST["log_in"], $_POST["mot_de_passe"]);
                    $oAuth = new Auth();
                    $user = $oAuth->findByEmail($_POST);
                    if ($user) {
                        if (password_verify($mot_de_passe, $user->mot_de_passe)) {
                            unset($user->mot_de_passe);
                            $_SESSION["Utilisateur"] = $user;
                            header("Location: " . URI . "films/index");
                        } else {
                            $this->render("login", ["erreur" => "couriel ou mot de passe invalide"]);
                        }
                        // var_dump($user);
                    }
                }
            }


        }

        $this->render("login");

    }

    public function deconnexion()
    {
        unset($_SESSION["Utilisateur"]);
        header("Location: " . URI . "films/index");
    }
}